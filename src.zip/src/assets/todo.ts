export interface Countries{
    country: string;
    name: string;
    domains: string[];
    alpha_two_code: string;
    state_province: string;
    web_pages: string[];
}