import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Countries } from '../assets/todo';

@Injectable({
  providedIn: 'root'
})
export class TodoService {

    constructor(private http: HttpClient) { }


      url = 'http://universities.hipolabs.com/search?country=';

      // get all details
      getApi(countryName: string):Observable<Countries[]>{
       return this.http.get<Countries[]>(this.url + countryName) 
     }
}
