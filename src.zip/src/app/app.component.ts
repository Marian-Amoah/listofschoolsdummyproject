import { Component, OnInit } from '@angular/core';
import { TodoService } from './todo.service'
import { map } from 'rxjs/operators';
import { Countries } from '../assets/todo';
import { FormGroup, FormControl, FormBuilder,ReactiveFormsModule  } from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'Countries and Available Universities';
  
  universities: Countries[] = [];
  
  constructor(private universityService: TodoService)
  {}

  formData = new FormGroup({
    country: new FormControl(''),
});
  ngOnInit(){ }

getAllUniversities(){
  this.universityService.getApi(this.formData.value.country).subscribe
  ({
      next:(result:Countries[]) =>{
        if(result.length === 0){
          alert('country not found')
        } else {
      this.universities = result.map((function(country: Countries){
        return country;
      }))
    }
    console.log(this.universities);
  }
});
}
}

